/*
0	group
1	status
2	installed
3	name / image src
4	key
5	desc
6	link
⌥
*/

let SHEET_ID = '1oQGnzagrCDBZqZ5-GLmvjxiVnL0VoHSMOBGiUZ9ZHmg'
let SHEET_TITLE = 'Plugins';
let SHEET_RANGE = 'D2:J156';
let FULL_URL = ('https://docs.google.com/spreadsheets/d/' + SHEET_ID + '/gviz/tq?sheet=' + SHEET_TITLE + '&range=' + SHEET_RANGE);
fetch(FULL_URL)
	.then(res => res.text())
	.then(rep => {
		let data = JSON.parse(rep.substr(47).slice(0, -2));
		let plugins_list = document.getElementById('plugins-list');
		let length = data.table.rows.length;

		for (let i = 1; i < length; i++) {
				let NewBox = document.createElement('div');
				let Link = document.createElement('a');
				NewBox.append(Link);

				let Preview = document.createElement('div');
				let Info = document.createElement('div');

				let Group = document.createElement('span');
				// let Key = document.createElement('span');
				let Status = document.createElement('p');
				let PreviewImg = document.createElement('img');

				let PluginName = document.createElement('h4');
				let Description = document.createElement('p');

				// if (data.table.rows[i].c[3]) {
				// 	Key.innerHTML = data.table.rows[i].c[3].v
				// }

				// Link.href = data.table.rows[i].c[6].v;
				// Link.target = "_blank";
				Link.className = "plugins-item-content";

				// Status.innerHTML = data.table.rows[i].c[0].v;
				// Group.innerHTML = data.table.rows[i].c[0].v;
				Group.innerHTML = data.table.rows[i].c[0];
				PreviewImg.src = `img/preview/${data.table.rows[i].c[3].v}.png`;

				PluginName.innerHTML = data.table.rows[i].c[3].v;
				// Description.innerHTML = data.table.rows[i].c[5].v;



				PreviewImg.className = "img_style";
				NewBox.className = `plugins-item ${data.table.rows[i].c[0]} ${data.table.rows[i].c[4]} show`;
				Info.className = "plugin-info";


				Link.append(Preview, Info);
				Preview.append(PreviewImg, Status)
				Preview.className = "cover";

				Info.append(PluginName, Description);

			plugins_list.append(NewBox);
			// if (Key.textContent != 0) { Key.style.cssText = "display:block; background:red" }
		}

	});
	document.querySelector('#search-input').addEventListener('input', filterList);

	function filterList() {
		const searchInput = document.querySelector('#search-input');
		const filter = searchInput.value.toLowerCase();
		const listItems = document.querySelectorAll('.plugins-item');
		listItems.forEach((item) => {
			let text = item.textContent;
			if (text.toLowerCase().includes(filter.toLowerCase())) {
				item.style.display = '';
			} else {
				item.style.display = 'none';
			}
		});

	}

	filterSelection("all")
	function filterSelection(c) {
		var x, i;
		x = document.getElementsByClassName("plugins-item");
		if (c == "all") c = "";
		for (i = 0; i < x.length; i++) {
			removeShowClass(x[i], "show");
			if (x[i].className.indexOf(c) > -1) addShowClass(x[i], "show");
		}
	}

	function addShowClass(element, name) {
		var i, arr1, arr2;
		arr1 = element.className.split(" ");
		arr2 = name.split(" ");
		for (i = 0; i < arr2.length; i++) {
			if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}
		}
	}

	function removeShowClass(element, name) {
		var i, arr1, arr2;
		arr1 = element.className.split(" ");
		arr2 = name.split(" ");
		for (i = 0; i < arr2.length; i++) {
			while (arr1.indexOf(arr2[i]) > -1) {
				arr1.splice(arr1.indexOf(arr2[i]), 1);
			}
		}
		element.className = arr1.join(" ");
	}

	// Add active class to the current button (highlight it)
	var btnContainer = document.getElementById("filters");
	var btns = btnContainer.getElementsByClassName("btn");
	for (var i = 0; i < btns.length; i++) {
		btns[i].addEventListener("click", function(){
			var current = document.getElementsByClassName("active");
			current[0].className = current[0].className.replace(" active", "");
			this.className += " active";
		});
	}